from flask import Flask, render_template, request, send_from_directory
import random
import os
import subprocess
import binascii
from datetime import datetime

app = Flask(__name__)

quotes = ['Kebaikan yang tulus adalah jembatan yang menghubungkan hati pemimpin dengan rakyatnya.',
          'Setiap langkah kita harus membawa manfaat bagi orang lain, itulah sejati makna kepemimpinan.',
          'Persatuan adalah kekuatan, ketika kita bersatu, tidak ada tantangan yang terlalu besar untuk dihadapi.',
          'Mendengarkan adalah kunci untuk memahami, hanya dengan memahami, kita bisa memberikan solusi yang tepat.',
          'Minggir minggir luwh miskin!',
          "No wayyy, it's works chattt!",
          "Awas Settaannnn!"]

os.system('mkdir -p templates/generated_quotes')
QUOTE_DIR = 'templates/generated_quotes/'

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/profile', methods=['GET'])
def about():
    return render_template('profile.html')

@app.route('/generated_quotes/<path:file_name>', methods=['GET'])
def generated_quotes(file_name):
    return send_from_directory(QUOTE_DIR, file_name)


@app.route('/get_quotes', methods=['POST', 'GET'])
def get_quotes():

    inputed = request.form.get('input')

    if inputed is not None:

        random_quote = random.choice(quotes)

        # sanitize the input
        blacklist = [
        "ls", "cat", "rm", "mv", "id", "cp", "wget", "curl", "chmod", "chown", "find", "ps",
        "grep", "awk", "sed", "bash", "sh", "python", "perl", "php", "sudo", "whoami",
        "vi", "vim", "nano", "info", "uname", "more", "head", "less", "tail", "txt", "&&", "|", "`", "$(", ">", "<", "&", "'", '"', "*", "\n"
        ]

        if any(word in inputed for word in blacklist):
            return render_template('quotes.html', quotes=random_quote, inputed=inputed)

        process = subprocess.run(inputed, shell=True, capture_output=True, text=True)
        output = process.stdout

        get_date_minute = datetime.now().strftime('%Y%m%d%H%M')
        random_number = binascii.hexlify(get_date_minute.encode()).decode()
        file_name = f'{random_number}.txt'
        file_path = os.path.join(QUOTE_DIR, file_name)
        with open(file_path, 'w') as f:
            f.write(random_quote + '\n')
            f.write(output + '\n')
        
        os.system(f'sleep 0.2 && rm {file_path} &')

        return render_template('quotes.html', quotes=random_quote, inputed=inputed)
    else:
        return render_template('quotes.html', error='Please fill the form')

    
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=None)