---
title: Mwsamanaga
emoji: 🏆
colorFrom: green
colorTo: indigo
sdk: gradio
sdk_version: 5.15.0
app_file: app.py
pinned: false
short_description: Some other CTF thingy, dw abt it
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
