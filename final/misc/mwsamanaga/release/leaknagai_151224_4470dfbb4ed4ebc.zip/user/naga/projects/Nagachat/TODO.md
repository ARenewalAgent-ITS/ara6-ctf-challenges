# TODOS
[x] Functional generation  
[x] User interface  
[x] COnfig saving  
[x] Config loading
[x] ratelimiting (to be tested)  
[] better UI (ongoing)    
[x] FAISS  
[x] Nice unrestricted model (decided on https://huggingface.co/mradermacher/L3.2-JametMini-3B-MK.III-GGUF)
[x] RAG  
[] Better embedding models???  
[] Better rAG?? (CoT??)  
[] REMOVE AND OMIT SENSITIVE SHIT FROM THE INDEXES (ongoing)
