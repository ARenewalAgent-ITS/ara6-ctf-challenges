function report(){
    alert("Data SuccessFully Spawned");
}